import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-U4R66NLH.js";
import "./chunk-6NFFGRSQ.js";
import "./chunk-WJSZD743.js";
import "./chunk-C755MU5X.js";
import "./chunk-RXV37I5I.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-4GHFISGN.js";
import "./chunk-UOPINYA3.js";
import "./chunk-5IW5ZEPE.js";
import "./chunk-RPWZ4CMX.js";
import "./chunk-NQ4HTGF6.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
