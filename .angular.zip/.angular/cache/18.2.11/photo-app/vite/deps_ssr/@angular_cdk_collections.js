import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  ArrayDataSource,
  DataSource,
  SelectionModel,
  UniqueSelectionDispatcher,
  _DisposeViewRepeaterStrategy,
  _RecycleViewRepeaterStrategy,
  _VIEW_REPEATER_STRATEGY,
  _ViewRepeaterOperation,
  getMultipleValuesInSingleSelectionError,
  isDataSource
} from "./chunk-GAHZQWMB.js";
import "./chunk-4GHFISGN.js";
import "./chunk-UOPINYA3.js";
import "./chunk-5IW5ZEPE.js";
import "./chunk-RPWZ4CMX.js";
import "./chunk-NQ4HTGF6.js";
export {
  ArrayDataSource,
  DataSource,
  SelectionModel,
  UniqueSelectionDispatcher,
  _DisposeViewRepeaterStrategy,
  _RecycleViewRepeaterStrategy,
  _VIEW_REPEATER_STRATEGY,
  _ViewRepeaterOperation,
  getMultipleValuesInSingleSelectionError,
  isDataSource
};
//# sourceMappingURL=@angular_cdk_collections.js.map
