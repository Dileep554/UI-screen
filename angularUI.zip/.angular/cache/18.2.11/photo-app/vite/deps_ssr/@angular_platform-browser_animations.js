import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  BrowserAnimationsModule,
  InjectableAnimationEngine,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations
} from "./chunk-IKKJNMAT.js";
import "./chunk-3NO2IVBO.js";
import "./chunk-3YAWAQRK.js";
import "./chunk-LXE4UF3O.js";
import "./chunk-6E7ER37X.js";
import {
  ANIMATION_MODULE_TYPE
} from "./chunk-DDME52US.js";
import "./chunk-5IW5ZEPE.js";
import "./chunk-UOPINYA3.js";
import "./chunk-RPWZ4CMX.js";
import "./chunk-NQ4HTGF6.js";
export {
  ANIMATION_MODULE_TYPE,
  BrowserAnimationsModule,
  NoopAnimationsModule,
  provideAnimations,
  provideNoopAnimations,
  InjectableAnimationEngine as ɵInjectableAnimationEngine
};
//# sourceMappingURL=@angular_platform-browser_animations.js.map
