import { Component, ViewChild, AfterViewInit } from '@angular/core';
import { DashboardComponent } from '../dashboard/dashboard.component';

@Component({
  selector: 'app-photo',
  templateUrl: './photo.component.html',
  styleUrls: ['./photo.component.css']
})
export class PhotoComponent implements AfterViewInit {
  filterCriteria: any = {};

  @ViewChild(DashboardComponent) dashboard!: DashboardComponent;

  ngAfterViewInit(): void {
    this.updateSelectedCounts({
      albumIds: this.filterCriteria.albumIds || [],
      ids: this.filterCriteria.ids || [],
      titles: this.filterCriteria.titles || [],
      urls: this.filterCriteria.urls || []
    });
  }

  onFilterChange(criteria: any): void {
    this.filterCriteria = criteria;
    this.updateSelectedCounts(criteria);
  }
  


  updateSelectedCounts(selectedCounts: any): void {
    if (this.dashboard) {
      this.dashboard.updateSelectedCounts({
        albumIds: selectedCounts.albumIds || [],
        ids: selectedCounts.ids || [],
        titles: selectedCounts.titles || [],
        urls: selectedCounts.urls || []
      });
    }
  }
}
