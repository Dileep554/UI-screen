import { Component, Input, ViewChild } from '@angular/core';
import { DashboardComponent } from '../dashboard/dashboard.component';

@Component({
  selector: 'app-radio-button',
  templateUrl: './radio-button.component.html',
  styleUrl: './radio-button.component.css'
})
export class RadioButtonComponent {
  selectedOption: string = 'option1'; // Default selection
  @ViewChild(DashboardComponent) dashboard!: DashboardComponent;
  @Input() filterCriteria: any; 

  onFilterChange(criteria: any): void {
    this.filterCriteria = criteria;
    this.updateSelectedCounts(criteria);
  }

  updateSelectedCounts(selectedCounts: any): void {
    this.dashboard.updateSelectedCounts(selectedCounts);
  }

  

}
